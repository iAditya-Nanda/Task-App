# TaskFlow

Hey! Welcome to **TaskFlow**. We built this to make task management actually feel *good*. It's a full-stack setup with a super premium Web Dashboard and a matching Flutter Mobile App. 

Everything is synced up, looks beautiful, and just works. Here’s the quick breakdown on how to get it all running on your machine.

---

## Quick Start Guide

### 1. The Engine (Backend)
First, we need to get the server up and running so the apps have someone to talk to.

*   **Setup:**
    ```bash
    cd backend
    npm install
    npx prisma generate
    npx prisma db push
    ```
*   **Run it:**
    ```bash
    npm run dev
    ```
    *Server will be live on: `http://localhost:3000`*

---

### 2. The Dashboard (Web)
This is the high-end workspace for your browser.

*   **Setup:**
    ```bash
    cd web
    npm install
    ```
*   **Run it:**
    ```bash
    npm run dev
    ```
    *Open `http://localhost:3001` to see the magic.*

---

### 3. The App (Mobile)
A premium Flutter app with glassmorphism, smooth animations, and a clean UI.

*   **Setup:**
    ```bash
    cd mobile
    flutter pub get
    ```
*   **Running on a Physical Phone (Crucial Step):**
    If you're using a real phone via USB, you **must** run this command so the phone can "see" your backend:
    ```bash
    adb reverse tcp:3000 tcp:3000
    ```
*   **Run it:**
    ```bash
    flutter run
    ```

---

## What's Inside?

*   **Web Dashboard:** Built with Next.js, Framer Motion for those smooth transitions, and a clean "Glass" aesthetic.
*   **Mobile App:** Flutter + Riverpod for rock-solid state management. We used custom SVGs and premium micro-animations to make it feel high-end.
*   **Auth:** Secure Login/Register on both platforms with automatic token refreshing (no more annoying logouts).
*   **CRUD:** Add, Edit, Delete, and Toggle tasks anywhere—everything stays in sync.

---

## 🛠 Tech Stack
*   **Frontend:** Next.js, Tailwind CSS, Lucide Icons
*   **Mobile:** Flutter, Riverpod, Flutter Animate
*   **Backend:** Express.js, Prisma, PostgreSQL
*   **State:** TanStack Query (Web) & Riverpod (Mobile)

Enjoy the clean workspace! If you run into any connection issues on the phone, just remember the `adb reverse` trick!
